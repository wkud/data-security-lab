# to compile and run rsa_key.CPP, use this commands:
g++ -o rsa_key.exe rsa_key.cpp
./rsa_key.exe

# to compile and run rsa_key_file.CPP, use this commands:
g++ -o rsa_key_file.exe rsa_key_file.cpp
./rsa_key_file.exe